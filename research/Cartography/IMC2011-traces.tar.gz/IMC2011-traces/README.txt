Data release of dataset analyzed in:
"Web Content Cartography" 
Bernhard Ager, Wolfgang Muhlbauer, Georgios Smaragdakis and Steve Uhlig. 
ACM IMC 2011. 

Note, only 72 traces (out of 133) are made available with the permission of the users that
performed the experiment.

For more information please visit:
http://www.smaragdakis.net/research/Cartography

