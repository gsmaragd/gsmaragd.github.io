
"""
@summary: Selfish Neighbor Selection Project
@see:   http://csr.bu.edu/sns
@organization: DCS laboratory, ICS FORTH, Crete
@organization: WING group CS/BU, 2006-2008
@author: Vassilis Lekakis
@contact: lekakis@ics.forth.gr
@author: Georgios Smaragdakis
@contact: gsmaragd@cs.bu.edu
@version: 1.0
"""

from optparse import OptionParser
from cPickle import dumps
from cPickle import loads
from socket import *
from util import log
from copy import deepcopy
from time import time
from time import sleep
from pinger import *
from select import select
import traceback
import struct
import fcntl
import signal
import hashlib
import threading
import sys


STREAM          = '\r\r\t\t\n\n'
"""Marker denoting the end of data pkts """

END_OF_STREAM 	= '\r\t\n'
"""Marker denoting the end of flow """


BLK_SIZE        = 1024
"""Bulk size r """ 

DATA_PORT       = 11888
"""Listening port for data transfers """

BOOTING_PORT    = 11559
"""Port for accessing bootstrap to get initial information """

PKT_LEN         = 8196
"""Data pkts length """

HEADER          = 0
"""Packet field containing the type of the packet information """

HEADERS_DICT	= {'traffic_register':'TRG', 'data':'DAT', 'planetlab_srv_reg':'PLSRV_REG', 'egoist_proxy':'PRX', 'planetlab_srv':'PLSRV', 'planetlab_srv_dat':'PLSRV_DAT'}
"""data structure holding pkt header semantics
  @type: pyton dictionary keys: string, values: string 
"""



class EgoistEdge:
    """
        @summary:
    """
    def __init__(self, edge_ip, port, mode, filename, peer, boot_node):
        """
        Initialization method of EgoistEdge
        
        @param edge_ip: Machine's IP address
        @type edge_ip: String
            
        @param port: Port that sender and recevier will use
        @type port: Integer
        
        @param mode: EgoistEdge could be either sender or receiver
        @type mode: String
        
        @param filename: Name of the file to transfer/ or to store
        @type filename: String 
        
        @param peer: IP address of the other egoist-edge peer
        @type peer: String
        
        @param boot_node: IP address of the bootstrap node
        @type boot_node: String
        """
        self.net_info = (edge_ip, port) 
        self.mode = mode
        self.filename = filename
        self.peer = peer
        self.boot_node = boot_node
        self.sock = None
        self.pingMan = FPinger()

    def extractBootData(self):
        """
        Method that access bootstrap node in order to download node list
        """
        log('ExtractBootData...')
        self.sock = socket(AF_INET, SOCK_STREAM)
        self.sock.connect((self.boot_node, BOOTING_PORT))
        query_dat = dumps([HEADERS_DICT['traffic_register']])+END_OF_STREAM
        self.sock.sendall(query_dat)

	net_data = ''
	while True:
		tmp_data = self.sock.recv(BLK_SIZE)
		if tmp_data.endswith(END_OF_STREAM):
			net_data += tmp_data.partition(END_OF_STREAM)[0]
			break
		net_data += tmp_data
	self.sock.close()
	overlay_nodes = loads(net_data)[0]

        
        log('Overlay Data Accepted...')
        self.first_hop = self.findMinDistance(overlay_nodes)

    def findMinDistance(self, overlay_list):
        """
        Method that used to find the closest overlay node to the Egoist-Egde
        @param overlay_list: List with noodes that participating to the egosit overlay
        @type overlay_list: Python List of Strings 
        
        @rtype: Node's IP address that is closest to the Egoist-Edge, in terms of delay
        """
        
        log('Finding Minimum Distance Node...')
        ping_delays =  self.pingMan.isAlive(overlay_list, True)
        util_pings = deepcopy(ping_delays)
        revrs_pings = dict( map( lambda item: (item[1], item[0]), ping_delays.items()) )
        min_key = revrs_pings[ min(revrs_pings.keys()) ]
        return min_key
    
    def sigHandler(self, signum, frame):
        """
        A simple signal handler
        """
        log('Shutting down server...')
        sys.exit(-1)

    def registerAndHandshake(self):
        """
        Method that performs peer's registragtion to the closest
        egoist overlay node, that has been choose before.
        """
        log('Register Peer...')
        
        try:
           
            self.sock = socket(AF_INET, SOCK_STREAM)
            self.sock.connect((self.first_hop, BOOTING_PORT))
            query_dat = dumps( [HEADERS_DICT['planetlab_srv_reg'], (self.net_info)] )+END_OF_STREAM
            self.sock.sendall(query_dat)

            if self.mode == 'receiver':
                self.receiver()
            elif self.mode == 'sender':
                self.sender()
        except Exception, e:
            traceback.print_exc()

    def sender(self):
        """
        Egoist-Edge sender waits the other egoist-edge to inform it about its proxy
        overlay peer
        """
        log('Waiting the other peer to tell us its proxy overlay peer...')
        try:
            self.sock =  socket(AF_INET, SOCK_STREAM)
            self.sock.bind(self.net_info)
            self.sock.listen(5)
        
            proxy_data =''
            while True:
                in_sock, address = self.sock.accept()
                tmp_data = in_sock.recv(BLK_SIZE)
            
                if tmp_data.endswith(END_OF_STREAM):
                    proxy_data += tmp_data.partition(END_OF_STREAM)[0]
                    break
                proxy_data +=  tmp_data
            
            proxy_data = loads(proxy_data)
            if proxy_data[HEADER] != HEADERS_DICT['egoist_proxy']:
                log('Unable to continue, not excepected message')
                sys.exit(-1)
            else:
                proxy_egoist_peer = proxy_data[HEADER+1]
                self.transferData(proxy_egoist_peer)
        except Exception, e:
            traceback.print_exc()
        
            
    def receiver(self): 
        """
        Egoist-edge receiver firstly informs the sender about its proxy overlay
        node and then acts as a server, waiting for incoming data connections
        
        Every incoming request is served by a new thread
        """
        prx_data = dumps([HEADERS_DICT['egoist_proxy'], self.first_hop])+END_OF_STREAM
        self.sock = socket(AF_INET, SOCK_STREAM)
        self.sock.connect((self.peer, self.net_info[1]))
        
        self.sock.sendall(prx_data)
        self.sock.close()
        
        self.sock = socket(AF_INET, SOCK_STREAM)
        self.sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        
        self.sock.bind(self.net_info)
        self.sock.listen(5)
        signal.signal(signal.SIGINT, self.sigHandler)
        
        while True:
            clt_sock, addr = self.sock.accept()
            print clt_sock, addr
            t = threading.Thread(target=self.receiveData, args=(clt_sock,addr,))
            t.start()
            break
        
    def receiveData(self, sock, addr):
        """
        Method that exclude actual data from overlay packets' and store it
        to the file provided by the user
        @param sock: Incoming socket
        @type sock: Socket
        
        @param addr: Incoming client's address
        @type addr: Python Tuple
        """
        PAYLOAD =  3
        in_str = 'Receive-Data from: ' + addr[0]  + ' ...'
        log(in_str)
        bytes =''
        data = []
        more_data = True
        data_for_next =''
        while more_data:
            net_data = ''
            net_data += data_for_next
            data_for_next = ''
            while len(net_data) < PKT_LEN:
                net_bytes = sock.recv(PKT_LEN)
                net_data+=net_bytes
                net_bytes = ''
            
            
            if len(net_data) > PKT_LEN:
                real_data = net_data[:PKT_LEN]
                data_for_next = net_data[PKT_LEN:]
            else:
                real_data = net_data
            
            
            if len(real_data) == PKT_LEN:
                index = real_data.find(STREAM)
            
                if index == -1:
                    index = real_data.find(END_OF_STREAM)
                    if index != -1:
                        more_data = False
            
                if more_data and index != -1:
                    real_data = real_data[:index]
                
                
                try:
                    real_data = loads(net_data)
                except Exception,e:
                    print real_data
                    print len(net_data)
                    
                if real_data[HEADER] == HEADERS_DICT['planetlab_srv_dat']:
                    real_data = real_data[PAYLOAD]
                    data.append(real_data)
                elif real_data[HEADER] == HEADERS_DICT['planetlab_srv']:
                    more_data = False
                
            
            
        pure_bytes =''
        for pkt in data:
            pure_bytes+=pkt
                
        fptr = open(self.filename, 'wb')
        fptr.write(pure_bytes)
        fptr.close()
        
    
    def transferData(self, proxy_peer):
        """
        Method that sends data over the egoist overlay network
        @param proxy_peer: Receiver's proxy peer
        @type proxy_peer: String, IP address
        """
        sleep(5)
        log('Transfering Data...')
        
        try:
            
            fptr = open(self.filename, 'rb')
            pkt_cnt = 0
            self.sock = socket(AF_INET, SOCK_STREAM)
            self.sock.connect((self.first_hop, DATA_PORT))
            while True :
                payload = fptr.read(8000)
                if not payload: break
                p=dumps([HEADERS_DICT['planetlab_srv_dat'], proxy_peer, self.peer, payload])
                remain = PKT_LEN - len(p) - len(STREAM)
                p+=STREAM+remain*'\r'
                
                total_sent=0
                while total_sent < PKT_LEN:
                    sent = self.sock.send(p[total_sent:])
                    total_sent+=sent
                #print total_sent
                #print '---'
                payload =''
                p=''
                
    
            log('Sending End...')
            close_channel = dumps([HEADERS_DICT['planetlab_srv']])
            remain = PKT_LEN - len(close_channel)-len(END_OF_STREAM)
            close_channel+= END_OF_STREAM+remain*'\r'
            total_sent=0
            while total_sent < PKT_LEN:
                sent = self.sock.send(close_channel[total_sent:])
                total_sent+=sent
            self.sock.close()
            
        except IOError, e:
            traceback.print_exc()
            
        except Exception, e:
            traceback.print_exc()
        
    
        


def getIPAddress(ifname):
    """
    @param ifname: Interface name
    @type ifname: String
    """
    s = socket(AF_INET, SOCK_DGRAM)
    return inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

def extractSourceIP():
    """
    Method to extract local IP address if user don't give it through command line
    @rtype: String , the IP address
    """
    for interf in xrange(9):
        try:
            source_ip = getIPAddress('eth'+str(interf))
            break
        except IOError, e:
            pass
    return source_ip

def main():
    
    usage="""usage: python %prog [options] \n\n
    """
    parser = OptionParser(usage,version='%prog 1.0')
    
    parser.add_option('-m', '--mode', action='store', type='string', dest='mode', metavar='MODE', help='client working as sender or receiver choices are:[sender/receiver]')
    parser.add_option('-f', '--file', action='store', type='string', dest='file', metavar='FILE', help='file to transfer or to store')
    parser.add_option('-e', '--edge', action='store', type='string', dest='peer', metavar='PEER', help='the other peer that we want to communicate' )
    parser.add_option('-p', '--port', action='store', type='int', dest='port', metavar='PORT', help='communication ports of two edges')
    parser.add_option('-b', '--boot_node', action='store', type='string', dest='boot_node', metavar='BOOT_NODE', help='node to extract initial node list')
    
    (options, args) = parser.parse_args()
    source_ip = extractSourceIP()
    
    if options.mode == None:
        parser.error('option -m (or --mode) is mandatory')
    if options.mode != 'sender' and options.mode != 'receiver':
        parser.error('option -m (or --mode) can only take the following values [sender/receiver]')
    if options.peer == None:
        parser.error('option -e (or --edge) is mandatory')
    if options.boot_node == None:
        parser.error('option -b (or --boot_node) is mandatory')
    if options.port == None:
        parser.error('option -p (or --port) is mandatory')
    if options.file == None:
        if options.mode == 'sender':
            parser.error('in Sender mode option -f (or --file) is mandatory')
        else:
            print 'data will be stored in \' egoist_edge.dat \''
            options.file = 'egoist_edge.dat'
    
    egt_edge = EgoistEdge(source_ip, options.port, options.mode, options.file, options.peer, options.boot_node)
    egt_edge.extractBootData()
    egt_edge.registerAndHandshake()

if __name__ == '__main__':
    try:
        main()
    except Exception,e:
        traceback.print_exc()
    
