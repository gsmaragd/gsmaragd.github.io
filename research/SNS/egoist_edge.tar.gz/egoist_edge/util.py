

"""
@summary: Selfish Neighbor Selection Project
@see:   http://csr.bu.edu/sns
@organization: DCS laboratory, ICS FORTH, Crete
@organization: WING group CS/BU, 2006-2008
@author: Vassilis Lekakis
@contact: lekakis@ics.forth.gr
@author: Georgios Smaragdakis
@contact: gsmaragd@cs.bu.edu
@version: 1.0
"""

import time
import traceback
import sys

TIMEOUT         = 2000
SEC_TIMEOUT     = 2
END_OF_STREAM   = '\r\t\n'
NET_ADDRESS     = 0


def now():
    """
    @return: local time
    @rtype: string
    @note: It is used for logging purposes
    """
    return time.ctime(time.time())


def log(message, file=sys.stderr):
    """
    @param message: string to be written to log output
    @param file: log file ( default valuse is sys.stderr)
    @note: Printing logging messages to specified log file
    """
    t = now()
    file.write(str(t)+': '+message+'\n')


def getDiagnosis(exc_info):
    try:
        exc_pattern = (exc_info[0], exc_info[1])
        return ExcDiagDict[ repr(exc_pattern) ]
    except KeyError:
        return None
    except:
        return None    # maybe was not tuple?


def formatExceptionInfo(maxTBlevel=5):
         cla, exc, trbk = sys.exc_info()
         excName = cla.__name__
         try:
             excArgs = exc.__dict__["args"]
         except KeyError:
             excArgs = "<no args>"
         excTb = traceback.format_tb(trbk, maxTBlevel)
         return (excName, excArgs, excTb)

def BPHash(key):
    """
    @author: Arash Partow - 2002
    @see: http://www.partow.net
    @see: http://www.partow.net/programming/hashfunctions/index.html
    @see: http://www.opensource.org/licenses/cpl.php   
    @copyright: Free use of the General Purpose Hash Function Algorithms Library is
                permitted under the guidelines and in accordance with the most current
                version of the Common Public License
                
    """
    hash = 0
    for i in range(len(key)):
       hash = hash << 7 ^ ord(key[i])
    return hash


def DEKHash(key):
    """
    @author: Arash Partow - 2002
    @see: http://www.partow.net
    @see: http://www.partow.net/programming/hashfunctions/index.html
    @see: http://www.opensource.org/licenses/cpl.php   
    @copyright: Free use of the General Purpose Hash Function Algorithms Library is
                permitted under the guidelines and in accordance with the most current
                version of the Common Public License
                
    """
    hash = len(key);
    for i in range(len(key)):
      hash = ((hash << 5) ^ (hash >> 27)) ^ ord(key[i])
    return hash

def JSHash(key):
    """
    @author: Arash Partow - 2002
    @see: http://www.partow.net
    @see: http://www.partow.net/programming/hashfunctions/index.html
    @see: http://www.opensource.org/licenses/cpl.php   
    @copyright: Free use of the General Purpose Hash Function Algorithms Library is
                permitted under the guidelines and in accordance with the most current
                version of the Common Public License
    """
    hash = 1315423911
    for i in range(len(key)):
      hash ^= ((hash << 5) + ord(key[i]) + (hash >> 2))
    return hash

