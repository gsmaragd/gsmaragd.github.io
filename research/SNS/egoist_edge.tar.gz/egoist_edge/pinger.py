"""
@summary: Selfish Neighbor Selection Project
@see:   http://csr.bu.edu/sns
@organization: DCS laboratory, ICS FORTH, Crete
@organization: WING group CS/BU, 2006-2008
@author: Vassilis Lekakis
@contact: lekakis@ics.forth.gr
@author: Georgios Smaragdakis
@contact: gsmaragd@cs.bu.edu
@version: 1.0
"""


import util
from sys import stderr
from commands import getoutput
from sys import maxint
import thread

IS_ALIVE_FPING        =  '/usr/sbin/fping -c 1 %s'
"""Command pattern for Fpinger class"""

IS_ALIVE              = '/usr/sbin/fping %s'
SIMPLE_ALIVE          = 'alive'

ALIVE_PATTERN   =  '1/1/0%,'
"""Results' pattern denoting alive node"""

FAILURE_PATTERN =  '1/0/100%'
"""Results' pattern denoting unreachable node"""

NEW_LINE        =  '\n'
ZERO            =  0

ALIVE_INDEX     =  4
"""Index of reachability information in unparsed results"""

ALIVE           =  'Alive'
"""Denoting alive node with a string variable"""

UNREACHABLE     =  'Unreachable'
"""Denoting unreachable node with a string variable"""

DATA_INDEX      =  7
"""Data index, in unparsed results"""

IP_INDEX        =  0
"""IP address index, in unparsed results"""

PING_MAX_VAL    =  3000
"""Taken from sys.maxint, denoting an arithmetic delay for unreachable node"""  

MILLISEC        =  1000
"""number of millisec in one second, used for some conversions"""


"""
    Pinger class uses fping unix util to compute RTTs beetween user defined
    nodes. 
"""

class FPinger:
    """
    @note: Pinging class, used to gather RTTs from egoist network. With this
            module, nodes behind firewalls are seen as unreachable due to the
            fact that most firewalls drop ICMP messages
    @attention: fping , have to be installed to local machine
    @see: http://fping.sourceforge.net/
    """
    
    
    def __init__(self):
        """@note: Intialize Fpinge object"""
        util.log('fPinger Initiated..')
     
    def isAlive(self, nodes, need_rtts, cmd=None):
        """
        @param nodes: list of nodes to test
        @type nodes: python list
        @param need_rtts: denoting if caller functions need rtts
        @type need_rtts: boolean
        @return: nodes' status
        @rtype: python dictionary, {key:node / value:rtt/status}
        @note: Tests if given nodes are alive and also returns RTTs to caller
        """
        nodelist = ''
        for n in nodes:
            n = n.rstrip('\n')
            nodelist +=str(n+' ')
        if cmd == None:
            output = getoutput(IS_ALIVE_FPING % (nodelist))
            alive_dict = self.__parseOutput(need_rtts, output )
            return alive_dict
        else:
            output = getoutput(IS_ALIVE % (nodelist))
            alive_bool = self.__parseOutputAlive(output)
        
    
    def __parseOutputAlive(self,output):
        alive = 'alive'
        out = output.split()
        if alive == out[len(out)-1]:
            return True
        else:
            return False
    
    
    #   def:    __parseOutput
    #   inputs:  
    #       <need_rtts> :  boolean flag, that speficies if client needs rtts
    #       <unparsed_data>: the fping output
    #   output:
    #       <results>:  dictionary, with parsed fpings results
    #
    #   function:   parsing fpings output and returning rtts or query
    #               results (unreachable or not). It uses some simple
    #               string patterns to parse the output
    #               
    def __parseOutput(self, need_rtts, unparsed_data ):
        list = unparsed_data.split(NEW_LINE)
        results = {}
        status  = False
        for line in list:
            if len(line) > ZERO and status == False:
                continue
            if len(line) == ZERO:
                status = True
            elif len(line) > ZERO and status == True:
                lineD = line.split()
                if lineD[ALIVE_INDEX] == ALIVE_PATTERN:
                    results[lineD[IP_INDEX]] = ALIVE
                else:
                    results[lineD[IP_INDEX]] = UNREACHABLE
                    
                if need_rtts == True:
                    if results[lineD[IP_INDEX]] == ALIVE:
                        data = lineD[DATA_INDEX].split('/')[ZERO]
                        results[lineD[IP_INDEX]] = self.__doNumber(data)
                    else:
                        results[lineD[IP_INDEX]] = PING_MAX_VAL
        return results                
    
    #   def:    __doNumber
    #   input:
    #       <data>: string , denotes fpings result
    #   output:
    #       <nun> : float millisecond representation of input data
    #
    #   function:   just a numner conversion from string sec to float millisec
     
    def __doNumber(self, data):
        try:
            num  = float(data)
            
        except ValueError, e:
            self.__log__('Value Error when parsing ping RTTs: from <Pinger> module')
            print str(e)
            system.exit(-1)
        return num
