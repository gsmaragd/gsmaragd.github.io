/* SNS client 
 * ----------
 * Georgios Smaragdakis
 * gsmaragd@cs.bu.edu
 * v.0.1 (c) 2006
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>

#define MAXLINE 5512
#define CLIENT_PORT 6996

#define CPU_LOAD_ENABLED 0 //1 if the cpu load monitor is enabled  <<-- input to the client

int main(int argc, char **argv)
{ 
  // Hostname  
  char * hostnamefile = "hostname.dat"; //filename for the hostname
  FILE * fp_hostname;
  char filename[MAXLINE];

  // Neighbors
  char * file_my_neighbors = "my_neighbors.dat"; //filename for the immediate neighbors
  FILE * fp_my_neighbors;
  
  //time
  time_t tp;
  struct tm *now;
	
  //Sockets
  int sockfd;
  int len;
  struct sockaddr_in server_address;

  int n_msg;
  char recvline[MAXLINE+1] = {0};

  // TO PING
  char cmd[MAXLINE];
  char * tempfile="tempfile.dat";  // temp file for general use
  char * delayfile = "delayfile.dat"; // file to store the delays with pings
  char * nodesfile = "nodes.dat"; //file that keeps the nodes (IP addr) in the overlay

  FILE *fp_nodes,*fp_tempfile;
  
  // TO PASS THE PINGS
  char * line = NULL;
  size_t line_len = 0;
  ssize_t line_read;
  FILE *fp;
  char temp[MAXLINE];

  int flag;
  int Rflag;
  int Uflag;
  int Wflag;
  int Eflag;

  //CPU LOAD
  FILE *fp_cpu_load;

  
  //Find the IP of the node (server)
  bzero(cmd, sizeof(cmd));
  	sprintf(cmd,"hostname -i > hostname.dat"); //; ./pathchirp_rcv&./pathchirp_snd&"); //INITIALIZE PATHCHIRP
     printf("\nSYSTEM CALL: %s",cmd);
     system(cmd);
     fp_hostname=fopen("hostname.dat","r");
 
     bzero(filename,sizeof(filename));
  	   while((line_read=getline(&line,&line_len,fp_hostname))!=-1)
             {
			   line[strlen(line)-1]='\0';
                  strcat(filename,line);
                  strcat(filename," ");
             }
     fclose(fp_hostname);
  
  
  if (argc<3)
      {
	printf("\nError: less than 3 arguments\n");
         printf("\n please use the following syntax:\n ./client -s <IP address> \n\n");
        exit (1);
      }
  if (argc==3)
     {
       if (strcmp(argv[1],"-s")==0)
	  {
            //printf("\n %s \n",argv[2]);
          }
       else
          {
            printf("\n please use the following syntax:\n ./client -s <IP address> \n\n");
            exit (1);
          }
     }

  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  server_address.sin_family = AF_INET;
  server_address.sin_addr.s_addr = inet_addr(argv[2]);
  server_address.sin_port = htons(CLIENT_PORT);
  len = sizeof(server_address);

  
for(;;){

// R(egister)
// W(iring request) 
// U(pdate)
// E(xit)

// better idea:
// Rflag, Uflag, Wflag, Eflag
// for Wiring you need to activate both Uflag+Wflag=1+1 in that order
	
Rflag=0;
Uflag=1;		//ENABLED->> 0 if Pyxida is used  PYXIDA
Wflag=1;
Eflag=0;
	
//FOR REGISTRATION ** BEGIN ////////////////////////////////////////
	if(Rflag==1)
	{
		if(connect(sockfd, (struct sockaddr*)&server_address, len)<0)
		{
	  		printf("Server: Error binding\n");
          	exit (1);
     	}
	
          bzero(temp,sizeof(temp)); 
		sprintf(temp,"R(egister)\n%s",filename);
	 	temp[strlen(temp)-1]='\0';
   		
		write(sockfd, temp, strlen(temp));
   		n_msg = read(sockfd, recvline, MAXLINE);
		
		
		recvline[n_msg]= 0;
   		printf("\n\n ** SNS REPORT MESSAGE (client) **\n");
		time(&tp);
		now=gmtime((const time_t*)&tp);
		fprintf(stdout,"GMT time: %d %d %d %2d:%02d:%02d\n",1900+now->tm_year,1+now->tm_mon,now->tm_mday,now->tm_hour,now->tm_min,now->tm_sec);
   		printf("[%d bytes received back]\n", n_msg);
   		printf(recvline);
   		printf("\n\n");

		// TO-DO: copy the rcv to "my_neighbors.dat"
		bzero(cmd,sizeof(cmd));  
		sprintf(cmd,"rm %s",file_my_neighbors);
     	printf("\nSYSTEM CALL: %s",cmd);
		system(cmd);
     	
		//WRITE THE NEW NEIGHBORS IN THE "my_neighbors.dat"
		fp_my_neighbors=fopen(file_my_neighbors,"w");	
		fprintf(fp_my_neighbors,"%s",recvline);
		fclose(fp_my_neighbors);	
	}
//FOR REGISTRATION ** END ////////////////////////////////////////


//FOR PING UPDATES ** BEGIN ////////////////////////////////////////
	if(Uflag==1)
	{

  		if(connect(sockfd, (struct sockaddr*)&server_address, len)<0)
		{
	  		printf("Server: Error binding\n");
          	exit (1);
     	}
   	
     		fp_nodes=fopen(nodesfile,"r");

			fp_tempfile=fopen("tempfile.dat","w");
			fclose(fp_tempfile);
     
			while((line_read=getline(&line,&line_len,fp_nodes))!=-1)
			{
				line[strlen(line)-1]='\0';

				bzero(cmd,sizeof(cmd));  
				sprintf(cmd,"ping -c 1 %s >> %s",line,tempfile);
				printf("\nSYSTEM CALL: %s",cmd);
				system(cmd);
     		}
			
			fclose(fp_nodes);
     
			bzero(cmd,sizeof(cmd));  
			sprintf(cmd,"perl retrieve_delays.pl %s > %s",tempfile,delayfile);
     		printf("\nSYSTEM CALL: %s",cmd);
     		system(cmd);

   			bzero(temp,sizeof(temp));
   			strcat(temp,"U(pdate)");
   			
   			fp=fopen("delayfile.dat","r");  
			while((line_read=getline(&line,&line_len,fp))!=-1)
			{
				strcat(temp,"\n");
   				strcat(temp,filename);
				strcat(temp,line);
				temp[strlen(temp)-1]=' ';
			}
     		temp[strlen(temp)-1]='\0';
     		fclose(fp);
   
    
   			//FOR PINGS
   			write(sockfd, temp, strlen(temp));
   			n_msg = read(sockfd, recvline, MAXLINE);
   			recvline[n_msg]= 0;
   
   			printf("\n\n ** SNS REPORT MESSAGE (client) **\n");
			//time
		     time(&tp);
		     now=gmtime((const time_t*)&tp);
		     fprintf(stdout,"GMT time: %d %d %d %2d:%02d:%02d\n",1900+now->tm_year,1+now->tm_mon,now->tm_mday,now->tm_hour,now->tm_min,now->tm_sec);
   			printf("[%d bytes received back]\n", n_msg);
   			printf(recvline);
   			printf("\n\n");
  	}
//FOR PING UPDATES ** END ///////////////////////////////////////////


// WIRING REQUEST ** BEGIN ////////////////////////////////////////
	if(Wflag==1)
	{
		if(connect(sockfd, (struct sockaddr*)&server_address, len)<0)
			{
	  			printf("Server: Error binding\n");
          		exit (1);
			}


		bzero(temp,sizeof(temp));
		if(CPU_LOAD_ENABLED==0)
		{
   			sprintf(temp,"W(iring request)\n%s",filename);
		}
		if(CPU_LOAD_ENABLED==1)
		{
			bzero(cmd,sizeof(cmd));  
			sprintf(cmd,"top -d 1 -n 1 > top.dat;perl retrieve_top_cpu.pl top.dat > top_cpu_load.dat");
     		printf("\nSYSTEM CALL: %s",cmd);
			system(cmd);

			fp_cpu_load=fopen("top_cpu_load.dat","r");
			while((line_read=getline(&line,&line_len,fp_cpu_load))!=-1)
				{
					sprintf(temp,"W(iring request)\n%s\n%s",filename,line);
				}
			fclose(fp_cpu_load);
		}
		

		fprintf(stdout,"\n%s",temp);
		
		write(sockfd, temp, strlen(temp));
   		n_msg = read(sockfd, recvline, MAXLINE);
   		recvline[n_msg]= 0;
		
		printf("\n\n ** SNS REPORT MESSAGE (client) **\n");	
		
		//time
		time(&tp);
		now=gmtime((const time_t*)&tp);
		fprintf(stdout,"GMT time: %d %d %d %2d:%02d:%02d\n",1900+now->tm_year,1+now->tm_mon,now->tm_mday,now->tm_hour,now->tm_min,now->tm_sec);
   		printf("[%d bytes received back]\n", n_msg);
   		printf(recvline);
		
		//WRITE THE NEW NEIGHBORS IN THE "my_neighbors.dat"
		fp_my_neighbors=fopen(file_my_neighbors,"w");	
		fprintf(fp_my_neighbors,"%s",recvline);
		fclose(fp_my_neighbors);
	}
// WIRING REQUEST ** END ////////////////////////////////////////



// EXIT ** BEGIN ////////////////////////////////////////
	if(Eflag==1)
		{
			bzero(temp,sizeof(temp));
   			sprintf(temp,"E(xit)\n%s",filename);
			fprintf(stderr,"\n%s",temp);
  			
			if(connect(sockfd, (struct sockaddr*)&server_address, len)<0)
			{
	  			printf("Server: Error binding\n");
          		exit (1);
			}
   			
			write(sockfd, temp, strlen(temp));
   			n_msg = read(sockfd, recvline, MAXLINE);
   			recvline[n_msg]= 0;
   			
			printf("\n\n ** SNS REPORT MESSAGE (client) **\n");
			
			//time
		     time(&tp);
		     now=gmtime((const time_t*)&tp);
		     fprintf(stdout,"GMT time: %d %d %d %2d:%02d:%02d\n",1900+now->tm_year,1+now->tm_mon,now->tm_mday,now->tm_hour,now->tm_min,now->tm_sec);
   			printf("[%d bytes received back]\n", n_msg);
   			printf(recvline);
   			printf("\n\n");
		}
// EXIT ** END ////////////////////////////////////////
	
	sleep(60);	//300);
	}

//fclose(fp_hostname);
}
