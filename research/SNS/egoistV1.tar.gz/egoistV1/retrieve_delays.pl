#/*SNS client 
#* ----------
#* Georgios Smaragdakis
#* gsmaragd@cs.bu.edu
#* v.0.1 (c) 2006
#*/

#!/usr/bin/perl

#returns the average delay

$data=$ARGV[0];

open DATA, $data;

$STATISTICS="statistics";
$RTT="rtt";
$TRANSMITTED="transmitted";

$flag=0;
while (<DATA>){
	if($_ =~ /$STATISTICS/) {
		@line=split(/ /,$_);
		print "$line[1] ";
	}
	if($_ =~ /$TRANSMITTED/) {
		@line2=split(/ /,$_);
		if($line2[3]=='0'){
			print "999\n";
		}
	}
	if($_ =~ /$RTT/) {
		@line3=split(//,$_);
		print "$line3[23]$line3[24]$line3[25]$line3[26]$line3[27]\n";
	}
}
