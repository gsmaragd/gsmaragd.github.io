"""
@author: Vassilis Lekakis
@organization: Institute of Computer Science, F.O.R.T.H
@contact: lekakis@ics.forth.gr/lekakis@gmail.com/lex@umd.edu
@see: U{http://csr.bu.edu/sns/}
@see: U{http://www.ics.forth.gr/~lekakis}
"""
"""
@summary: module with the constants needed from egoist main entities in order
to be able to communicate 
"""

from sys import maxint


REGISTER             = 'REG'
UPDATE               = 'UPT'
REMOVE               = 'RMV'
TEARDOWN             = 'TRD'
PORT_DELIMITER       = ':'
PACK_DELIMITER       = '@'
UPDT_DELIMITER       = '**'
NEIGHBOR_DELIMITER   = '|'
OVERLAY_DELIMITER    = '#'
NACK                 = 'NACK'
REMOVE_PERIOD        = 50
PACKET_TYPE          = 0
BOOTSTRAP_PORT       = 61223
BOOT_DELAY           = 500
HUGE_DELAY           = maxint-1000
NBR_IP               = "NEIGHBOR_IP"
NBR_PORT             = "NEIGHBOR_PORT"
NBR_FACTORY          = "NEIGHBOR_FACTORY"
NBR_CONNECTOR        = "NEIGHBOR_CONNECTOR"
PKT_IDS_LIMIT        = 5000
UPDATE_HASH          = 1
UPDATE_ID            = 2
UPDATE_SRC           = 3
MIL                  = 1000
PING_PERIOD          = 35
REWIRING_PERIOD      = 60
ERASE_HASH           = 5 * REWIRING_PERIOD
PING_TIMEOUT         = 3
PING_RESULTS         = 'PING_MEASURMENTS'
PING_FACTORY         = 'PING_FACTORY'
SEG                  = 'SEG'
OVERLAY_PACKET       = 'OVER'
NET_PACKET           = 'NET'
PKT_LIMIT            =  8190
