"""
@author: Vassilis Lekakis
@organization: Institute of Computer Science, F.O.R.T.H
@contact: lekakis@ics.forth.gr/lekakis@gmail.com/lex@umd.edu
@see: U{http://csr.bu.edu/sns/}
@see: U{http://www.ics.forth.gr/~lekakis}
"""

from sys import path
path.append('../../')
from priorityDictionary import PriorityDictionary
from egoist.constants.ntwrsemantics import HUGE_DELAY


def Dijkstra(G,start,end=None):
    """
    The classic algorithm with the use of a pririotity dictionary
    """
    try:
        
        D = {}
        P = {}
        Q = PriorityDictionary()   # est.dist. of non-final vert.
        Q[start] = 0

        for v in Q:
            D[v] = Q[v]
            if v == end: break
            
            if v not in G.keys(): continue
            for w in G[v]:
                vwLength = D[v] + G[v][w]
                if w in D:
                    if vwLength < D[w]:
                        raise ValueError, "Dijkstra: found better path to already-final vertex"
                elif w not in Q or vwLength < Q[w]:
                    Q[w] = vwLength
                    P[w] = v

        for nd in G.keys():
            if nd not in D.keys():
                D[nd] = HUGE_DELAY
                P[nd] = 'None'
        return (D,P)
    except Exception, e:
        pass
    finally:
        return (D,P)


