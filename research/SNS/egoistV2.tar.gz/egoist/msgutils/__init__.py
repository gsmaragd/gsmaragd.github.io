"""
@author: Vassilis Lekakis
@organization: Institute of Computer Science, F.O.R.T.H
@contact: lekakis@ics.forth.gr/lekakis@gmail.com/lex@umd.edu
@see: U{http://csr.bu.edu/sns/}
@see: U{http://www.ics.forth.gr/~lekakis}
"""