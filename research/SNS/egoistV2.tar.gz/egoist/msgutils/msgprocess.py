"""
@author: Vassilis Lekakis
@organization: Institute of Computer Science, F.O.R.T.H
@contact: lekakis@ics.forth.gr/lekakis@gmail.com/lex@umd.edu
@see: U{http://csr.bu.edu/sns/}
@see: U{http://www.ics.forth.gr/~lekakis}
"""
"""
@summary: a collection of functions that perform the parsing of network
messages
"""
import traceback
from sys import path
path.append('../../')
from egoist.constants.ntwrsemantics import *

def set2str(overlay, MSG_TYPE):
    """
    converts the overlay set to a string
    @param overlay: the set that holds the alive nodes of the egoist network
    @type overlay: python set
    @return: The string representation of the set argument
    @rtype: String
    """
    netStr = MSG_TYPE
    for node in overlay:
        netStr+=PACK_DELIMITER+node
    netStr+=OVERLAY_DELIMITER
    return netStr


def dict2str(network, MSG_TYPE):
    """
    converts a dictionary to a string
    @param network:  the graph representation of the egoist overlay
    @type network: python dictionary
    @return: the string representation of the dictionary argument
    @rtype: String
    """
    netStr       = MSG_TYPE
    for src in network.keys():
        for dst in network[src]:
            netStr+=PACK_DELIMITER+src+PACK_DELIMITER+dst+PACK_DELIMITER+str(network[src][dst])
            netStr += NEIGHBOR_DELIMITER

    return netStr

def str2set(netstr, MSG_TYPE):
    """
    converts a string to a set
    @param netstr: incoming data from network
    @type netstr: String
    @return: a set constructed from the contents of the input string
    @rtype: python set
    """
    over = set()
    netdata = netstr.split(MSG_TYPE)[-1]
    netdata = netdata.split(PACK_DELIMITER)
    for i in netdata:
        if len(i) < 1:
            continue
        over.add(i)
    return  over


def str2dict(netstr, MSG_TYPE):
    """
    converts a string to a dictionary
    @param netstr: incoming data from network
    @type netstr: String
    @return: a dictionary constructed from the contents of the input string
    @rtype: python dictionary
    """
    try:
        net  = dict()
        netdata = netstr[len(MSG_TYPE):]
        links = netdata.split(NEIGHBOR_DELIMITER)

        for i in links:
            if len(i) < 1:
                continue
            i=i[len(PACK_DELIMITER):]
            src, dst, delay = i.split(PACK_DELIMITER)
            if src not in net.keys():  net[src] = dict()
            net[src][dst] = float(delay)

    except Exception,e:
        print str(e)
        traceback.print_exc()

    return net

def segmentBootPkt(over, net):
    """
    segmentation method. Packets that exceed the maximum amount of data
    that can be transported from Twisted (see documentation) are segmented
    to more packets with smaller sizes
    @param over: the nodes inside the egoist overlay
    @type over: python set
    @param net: the egoist overlay graph
    @type net: python dictionary
    @return: the packets that have been produced after the segmentation
    @rtype: python list
    """
    
    pkt_list = []
    overstr=OVERLAY_PACKET
    graphstr=NET_PACKET
    netstr = ''
    for i in over:

       if len(PACK_DELIMITER+i+SEG+overstr) > PKT_LIMIT:
           pkt_list.append(overstr+SEG)
           overstr=''
           overstr+=OVERLAY_PACKET+PACK_DELIMITER+i
       else:
           overstr+=PACK_DELIMITER+i


    if len(overstr) > 0:
        pkt_list.append(overstr)

    for i in net.keys():
        for dst in net[i]:
            netstr+=PACK_DELIMITER+i+PACK_DELIMITER+dst+PACK_DELIMITER+str(net[i][dst])
            netstr += NEIGHBOR_DELIMITER

            if len(graphstr+netstr+SEG) > PKT_LIMIT:
                pkt_list.append(graphstr+SEG)
                graphstr=''
                graphstr+=NET_PACKET+netstr
                netstr=''
            else:
                graphstr+=netstr
                netstr=''


    if len(graphstr)> 0:
        pkt_list.append(graphstr)


    return pkt_list

def pktBuildup(pkt_list):
    """
    when segmented packets are received this method builds up the initial packet
    @param pkt_list: the segmented packets
    @type pkt_list: python list
    @return: the actual data as extracted from the segmented packets
    @rtype: python tuple
    """
    try:
        over = REGISTER
        net  = REGISTER

        for pkt in pkt_list:
            type = pkt[:pkt.find(PACK_DELIMITER)]
            if type == OVERLAY_PACKET:
                if pkt.find(SEG) == -1:
                    over+=pkt[pkt.find(OVERLAY_PACKET)+len(OVERLAY_PACKET):]
                else:
                    over+=pkt[pkt.find(OVERLAY_PACKET)+len(OVERLAY_PACKET):pkt.find(SEG)]

            elif type == NET_PACKET:
                if pkt.find(SEG) == -1:
                    net+=pkt[pkt.find(NET_PACKET)+len(NET_PACKET):]
                else:
                    net+=pkt[pkt.find(NET_PACKET)+len(NET_PACKET):pkt.find(SEG)]

        over = str2set(over, REGISTER)
        net  = str2dict(net, REGISTER)
        return (over,net)
    except Exception,e:
        print str(e)
        traceback.print_exc()
