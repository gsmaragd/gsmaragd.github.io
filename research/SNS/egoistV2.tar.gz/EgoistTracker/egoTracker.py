#! /usr/bin/python
"""
@author: Vassilis Lekakis
@organization: Institute of Computer Science, F.O.R.T.H
@contact: lekakis@ics.forth.gr/lekakis@gmail.com/lex@umd.edu
@see: U{http://csr.bu.edu/sns/}
@see: {http://www.ics.forth.gr/~lekakis}

"""


import thread
from sys import path
path.append('../')

from egoist.msgutils.msgprocess import *
from egoist.constants.ntwrsemantics import *

from twisted.python import log
from twisted.internet import reactor
from twisted.internet import defer
from twisted.internet import protocol
from twisted.internet import task
from twisted.protocols.basic import LineOnlyReceiver
from optparse import OptionParser
from sys import stdout



class EgoTracker:
    """
    @summary: a class to unify information about the egoist bootstrap node
    """
    def __init__(self,ip,port):
        self.ip = ip
        self.port = port

    def getNetwork(self):
        return (self.ip, self.port)

    def getPort(self):
        return self.port

    def getIP(self):
        return self.ip

class EgoTrackerProtocol(LineOnlyReceiver):
    """
    @summary: The communication interface between the bootstrap node and the
    rest of the egoist peers. More information about the LineOnlyReceiver is
    located in the Twisted documentation
    @see: U{http://twistedmatrix.com/documents/current/api/twisted.protocols.basic.LineOnlyReceiver.html}
    """
    def lineReceived(self, line):
        
        if len(line) == 0:
            self.transport.loseConnection()
        else:
          
            type = line[:line.find(PACK_DELIMITER)]
            data = line[line.find(PACK_DELIMITER)+len(PACK_DELIMITER):]
            if type == REGISTER:
                print 'Before addoverlay data is ', data
                res = self.factory.addOverlayNode(data)
                if len(res) < PKT_LIMIT:
                    self.sendLine(res)
                else:
                    seg_pkts = segmentBootPkt(self.factory.overlayImg, self.factory.networkImg)
                    print 'Sending Large Packet', len(seg_pkts)
                    for pkt in seg_pkts:
                        #print len(pkt)
                        self.sendLine(pkt)
            elif type == UPDATE:
             
                self.factory.updateNeighbors(line)
                self.transport.loseConnection()
            elif type == REMOVE:
                print 'TRACKER RECEIVED REMOVE'
                self.factory.markRemove(data)
                self.transport.loseConnection()
            else:
                self.factory.log.msg('Unknown action sent to Tracker: '+str(type))
                self.transport.loseConnection()

   

class EgoTrackerFactory(protocol.ServerFactory):
    """
    @summary: Factory includes the main operations of the bootstrap node
    like addNode, updateGraph and removeNode. More on ServerFactory refer
    to the Twisted documentation
    @see:  U{http://twistedmatrix.com/documents/8.2.0/api/twisted.internet.protocol.ServerFactory.html}
    """
    protocol = EgoTrackerProtocol

    def __init__(self, log, networkId):
        self.log        = log
        self.networkId  = networkId
        self.ip         = networkId[0]
        self.port       = networkId[1]
        self.overlayImg = set()
        self.networkImg = dict()
        self.deferred   = defer.Deferred()
        self.eventBuf   = dict()
        self.accumRM    = task.LoopingCall(self.periodicRMV)
        self.mutex      = thread.allocate_lock()

    def __takeOrigin(self, testdict):
        SRC = 0
        for k in testdict.keys():
            origin = k[SRC]
            break
        return origin
    
    def startFactory(self):
        self.log.msg('EgoTracker-Factory started')
        self.accumRM.start(REMOVE_PERIOD)

    
    def addOverlayNode(self,nodeline):
        """
        adds a new node to the overlay set. Before the actual addition
        checks if this node is already inside
        @param nodeline: the new node
        @type nodeline: String
        """
        self.mutex.acquire(1)
        try:
            
            if nodeline not in self.overlayImg:
                self.overlayImg.add(nodeline)
                self.networkImg[nodeline] = dict()
                self.log.msg('Adding new Peer - '+str(nodeline))
                if nodeline not in self.eventBuf.keys():
                    self.eventBuf[nodeline]=[]
                self.eventBuf[nodeline].append(REGISTER)
                data = set2str(self.overlayImg, REGISTER )
                data = dict2str(self.networkImg, data)
                return data
            else:
                self.log.msg('Adding new Peer - Reason: Duplicate -'+str(nodeline))
                return ''
        except Exception,e:
            self.log.err(str(e))
        finally:
            self.mutex.release()

    def updateNeighbors(self,data):
        """
        Updates the overlay graph upon receiving a new update
        @param data: the update
        @type data: String
        """
        self.mutex.acquire(1)
        try:
            SRC = 0
            linkupdate = str2dict(data, UPDATE)
            origin = linkupdate.keys()[SRC]
            if origin in self.networkImg.keys():
                del self.networkImg[origin]
                self.networkImg[origin] = linkupdate[origin]
            
        except Exception, e:
            self.log.err(str(e))
        finally:
            self.mutex.release()

    def markRemove(self,nodeline):
        """
        Appends a remove event to the event buffer for the specified node
        @param nodeline: node candidate for removal
        @type nodeline: String
        @todo: Not sure that the whole idea is working correctly
        Needs to be redesign but in conjuction with the whole failure
        policy that will adopt the application over Egoist.
        """

        self.mutex.acquire(1)
        try:
            self.log.msg('Marked for Removal:\t'+str(nodeline))
            if nodeline not in self.eventBuf.keys():
                self.eventBuf[nodeline] = []
            self.eventBuf[nodeline].append(REMOVE)
        except Exception, e:
            print '--> Excetpion Remove'
            self.log.err(str(e))
        finally:
            self.mutex.release()
        
    def periodicRMV(self):
        """
        Methos that is called periodically and removes the nodes that in their
        event buffer have as a last element a REMOVE.
        @bug: It's not working correctly due to the fact that some nodes
        fail to connect temporarily to a node but the node is still alive.
        I guess that if we add to the event buffer a special Costant
        for every other action (REGISTER, UPDATE) the problem is going to
        be solved.
        """
        LAST_ELEM = -1
        self.mutex.acquire(1)
        try:
            for node in self.eventBuf.keys():
                if self.eventBuf[node][LAST_ELEM] == REGISTER:
                    continue
                elif self.eventBuf[node][LAST_ELEM] == REMOVE:
                    self.log.msg('Peridic Removal:\t'+str(node))
                    if node in self.overlayImg:
                        self.overlayImg.remove(node)
                    if node in self.networkImg.keys():
                        del self.networkImg[node]
            self.eventBuf.clear()
        except Exception,e:
            self.log.err(str(e))
        finally:
            self.mutex.release()


def main():

    usage = "usage: %prog [options] source_files"
    parser = OptionParser(usage, version="%prog 1.0")

    parser.add_option('-a' ,"--address", action="store", type="string", \
                  dest="ip", metavar="TRACKER_IP_ADDRESS", \
                  help="Tracker's ip address")

    parser.add_option('-p', '--port', action="store", type='int', \
                  dest='port', metavar='TRACKER_PORT', \
                  help="Tracker's listening port")

    parser.add_option("-l", '--log', action='store', type='string',\
                  dest='log', metavar='TRACKER_LOG_FILE', \
                  help="Tracker's log file")

    (options, args) = parser.parse_args()
    if options.ip is None:
        options.ip = ''
    if options.log is None:
        options.log = 'tracker.log'
    if options.port is None:
        options.port = BOOTSTRAP_PORT
        

    log.startLogging(stdout)
    log.msg('Tracker Started')
    egoTrg = EgoTracker(options.ip, options.port)
    egoTrgFactory = EgoTrackerFactory(log, egoTrg.getNetwork())
    reactor.listenTCP(egoTrg.getPort(), egoTrgFactory)
    reactor.run()


if __name__ == "__main__":
    from sys import path
    path.append('../')
    main()
    
