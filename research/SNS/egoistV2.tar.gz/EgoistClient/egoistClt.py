"""
@author: Vassilis Lekakis
@organization: Institute of Computer Science, F.O.R.T.H
@contact: lekakis@ics.forth.gr/lekakis@gmail.com/lex@umd.edu
@see: U{http://csr.bu.edu/sns/}
@see: {http://www.ics.forth.gr/~lekakis}

@note: The process of detected not alive neighbors and what is happening
after that, needs to be redesignned. For the time being, we just inoform
the bootstrap node about the problem but nothing more. We left that not
implemented on purpose because we believe that the strategy should be
followed have to be related to the application that is going to be
built atop the Egoist Overlay network.
@todo: The bootstraping from a proxy peer is not yet implemented
"""


import traceback
from sys import path
path.append('../')


from egoist.constants.ntwrsemantics import *
from egoist.msgutils.msgprocess import *
from thread import allocate_lock
from egoist.routing.dijkstra import Dijkstra

from optparse import OptionParser
from twisted.python import log
from twisted.internet import protocol
from twisted.internet import reactor
from twisted.internet import defer
from twisted.protocols.basic import LineOnlyReceiver
from time import time as clock


import traceback
from time import localtime
from time import ctime
from time import mktime
from hashlib import sha1
from random import randint


class EgoistNodeID:
    """
    @summary: This is the Egoist Node identity. We use this to group together
    all the necessary information about the Egoist peer.
    It's only purpose is only to group together information under one single
    type
    """
    def __init__(self, ip, port, k, bootp, pboot):
        """
        @param ip: node's ip
        @type ip: String
        @param port: egoist's listening port
        @type port: Integer
        @param k: number of outgoing links
        @type k: Integer
        @param bootp: ip address of bootstrap node
        @type bootp: Integer
        @param pboot: ip address of the proxy bootstap (not implemented)
        @type pboot: String
        """
        self.ip     = ip
        self.port   = port
        self.net    = (ip, port)
        self.K      = k
        self.boot   = bootp
        self.pboot  = pboot
        self.netstr = ip+PORT_DELIMITER+str(self.port)



class BootstrapProtocol(LineOnlyReceiver):
    """
    @summary: Here is definde the communication protocol of an
    Egoist peer and its bootstap node. Right now the bootstap is
    a special node, but in the case that someone wants to implement
    the proxy-based bootstap we believe that this class should be
    sufficient to facilitate the communication of the entities.
    For more details about the Twisted class LineonlyReceiver refer
    to the Twisted documetation
    @see: U{http://twistedmatrix.com/documents/current/api/twisted.protocols.basic.LineOnlyReceiver.html}
    """

    def __init__(self):
        self.over = ''
        self.net  = ''
        self.bigPacket = []

    def getData(self, msg):
        """
        Utility method that returns the bootstarp information to the
        Bootstrap Factory when the peer has received and has parsed the
        data

        @param msg: dummy
        @type msg: String
        @return: Bootstap Information (Overlay Nodes and Graph)
        @rtype: python tuple
        """
        if len(self.bigPacket) > 0:
            self.over, self.net = pktBuildup(self.bigPacket)

        return (self.over, self.net)


    def sendMsg(self, type, data):
        """
        A wrapper method of Linereceiver's sendLine. We need this wrapper
        cause different types of packets needs different processing

        @param type: packet type
        @type type: String
        @param data: data to be sent
        @type: python list
        """
        self.d = defer.Deferred()
        if type ==  REGISTER:
            msg=data[0]+PORT_DELIMITER+str(data[1])
            msg=REGISTER+PACK_DELIMITER+msg
            self.d.addCallback(self.getData)

        if type == UPDATE:
            msg=data

        if type == REMOVE:
            print 'Sending Remove Message to Bootstap'
            msg=data

        self.sendLine(msg)
        if type == REGISTER:    return self.d
        return


    def lineReceived(self, line):
        """
        Method that defines the behavior of the Egoist peer upon the
        reception of the bootstraping information.
        """
        if len(line) == 0:
            return
        pkt = line[:line.find(PACK_DELIMITER)]


        if pkt == REGISTER:
            
            overstr = line[:line.find(OVERLAY_DELIMITER)]
            netstr  = REGISTER+line[line.find(OVERLAY_DELIMITER)+1:]
            self.over = str2set(overstr, REGISTER)
            self.net  = str2dict(netstr, REGISTER)
            self.d.callback('Bootstrap Data Received')

        elif pkt == OVERLAY_PACKET:
            self.bigPacket.append(line)

        elif pkt == NET_PACKET:
            try:
                if line.find(SEG) == -1:
                    self.bigPacket.append(pkt)
                    self.d.callback('BootStrap Data Received')
                elif line.find(SEG) != -1:
                    self.bigPacket.append(pkt)
            except Exception,e:
                print str(e)
                traceback.print_exc()

        else:
            print '$'*20, 'bAD'
            print pkt


class PingProtocol(LineOnlyReceiver):
    """
    @summary: In order Egoist to estimate the quality of the links between
    the current peer and every other peer in the network needs to send a
    bit of information and measure the time that needed to get an answer
    from the other end of the communication. We already know that this is
    a quite rough way to estimate the quality of the link. We have driven
    to this though due to the fact that in the most cases ICMP is blocked
    from firewalls so we needed a quality mechanism coming from a higher
    layer. Second, in an earlier version we were measuring the time needed
    for a connection to be established (TCP handshake) but we observed that
    to open and close periodically too many connections was not very good
    solution due to the fact that many firewalls were treating to this behavior
    like a DoS. For more infromation about LineonlyReceiver please refer
    to the Twisted documents
    @see: U{http://twistedmatrix.com/documents/current/api/twisted.protocols.basic.LineOnlyReceiver.html}
    """
    timeout = 3
    def __init__(self):
        self.start=0
        self.stop =0

    def connectionMade(self):
        self.factory.wire = self.sendMsg


    def sendMsg(self,msg):
        self.factory.d = defer.Deferred()
        self.factory.start = clock()
        self.sendLine(msg)
        self.factory.d.addCallback(self.factory.handleResult)

    def lineReceived(self,line):
        if len(line) > 0:
            self.factory.diff = clock() - self.factory.start
            self.factory.d.callback((self.factory.node,self.factory.diff))


class PingFactory(protocol.ClientFactory):
    """
    @summary: For more information about ClientFactory please refer
    to the Twisted documents
    @see: U{http://twistedmatrix.com/documents/8.1.0/api/twisted.internet.protocol.ClientFactory.html}
    """
    protocol = PingProtocol
    def __init__(self,node, handler):
        self.wire           = None
        self.d              = None
        self.start          = 0
        self.diff           = 0
        self.node           = node
        self.handleResult   = handler


class NeighborTalkingProtocol(LineOnlyReceiver):
    """
    @summary: Here is defined the interface of communication between two
    egoist peers.
    @see: U{http://twistedmatrix.com/documents/current/api/twisted.protocols.basic.LineOnlyReceiver.html}
    """

    def connectionMade(self):
        self.factory.wire = self.sendMsg
        self.factory.d.callback("test")

    def sendMsg(self,msg):
        self.sendLine(msg)

    def lineReceived(self, line):
        print 'None Talks here:\t', line

class NeighborTalkingFactory(protocol.ClientFactory):
    """
    @summary: Here is defined how the connection between two egoist neighbors
    is handled. More informations about ClientFactory could be found in
    Twisted documents
    @see U{http://twistedmatrix.com/documents/8.1.0/api/twisted.internet.protocol.ClientFactory.html}
    """
    protocol = NeighborTalkingProtocol

    def __init__(self, rmFunction, node):
        self.d = defer.Deferred()
        self.wire = None
        self.removeNode = rmFunction
        self.node = node
        self.changingNeighbor = False

    def getNBRDeferred(self):
        return self.d

    def clientConnectionLost(self, connector, reason):

        if self.changingNeighbor == False:
            self.removeNode(self.node)

    def clientConnectionFailed(self, connector, reason):
        self.removeNode(self.node)

    def disconnectFromNeighbor(self, connector):
        log.msg('Disconnecting from NeighBor:\t'+str(connector.getDestination()))
        #connector.disconnect()


class NeighborListeningProtocol(LineOnlyReceiver):
    """
    @summary: Defines the way that two egoist neighbors communicate
    @see: U{http://twistedmatrix.com/documents/current/api/twisted.protocols.basic.LineOnlyReceiver.html}
    """
    def connectionMade(self):
       print 'Connected: \t' , self.transport.getPeer()

    def lineReceived(self,line):
    
        pkt =  line[:line.find(PACK_DELIMITER)]
        if pkt == UPDATE:

            data = line.split(PACK_DELIMITER)
            dup  = self.factory.isDuplicate(data[UPDATE_HASH])
            fresh = self.factory.isFresh(data[UPDATE_SRC],int(data[UPDATE_ID]))
            
            if dup == True:     return
            if fresh == False:  return
            
            self.factory.processUpdate(data[UPDATE_HASH] \
                            , data[UPDATE_ID], data[UPDATE_SRC],line)
        if pkt == TEARDOWN:
            self.transport.loseConnection()


class DummyProtocol(LineOnlyReceiver):
    """
    @summary: It accepts a bucket from the rest overlay nodes and send it back.
    This protocol facilitates the link quality mechanish in order egoist peers
    to be able to infer the link quality.
    @see: U{http://twistedmatrix.com/documents/current/api/twisted.protocols.basic.LineOnlyReceiver.html}
    """
    def lineReceived(self,line):
        try:
            self.sendLine(line)
        except Exception,e:
            print str(e)
            print '*'*77
            traceback.print_exc()

class DummyFactory(protocol.ServerFactory):
    """
    @summary: Factory for the link quality port
    @see: U{http://twistedmatrix.com/documents/8.2.0/api/twisted.internet.protocol.ServerFactory.html}
    """
    protocol = DummyProtocol

        

class EgoistClientFactory(protocol.Factory):
    """
    @summary: this is the actual egoist peer. It is a Facotry both Client/Server
    in order to be able to communicate and listen the rest of egoist peers
    @see: More information of fattories U{http://twistedmatrix.com/documents/8.2.0/api/twisted.internet.protocol.Factory.html}
    """
    protocol = NeighborListeningProtocol
    
    
    def __init__(self, egoid):
        self.egoid = egoid
        self.overlay        = set()
        self.network        = dict()
        self.neighbors      = dict()
        self.pktid          = 0
        self.hashdata       = set()
        self.netids         = dict()
        self.pingdata       = dict()
        self.pingenabled    = False
        self.mutex          = allocate_lock()
        self.brenabled      = False
        
        
        
    def __sendBoot(self, p, type, msg):
        d = p.sendMsg(type, msg)
        return d

    def __send2Neighbor(self,data,n,msg):
        self.neighbors[n][NBR_FACTORY].wire(msg)
        

    def __initBoot(self, data):
        (OVER,NET) = xrange(2)
        self.overlay = data[OVER]
        self.network = data[NET]
        self.network[self.egoid.netstr] = dict()
        reactor.callLater(ERASE_HASH, self.__eraseHash)
        self.formOverlay()

    def __eraseHash(self):
        self.mutex.acquire(1)
        try:
            self.hashdata.clear()
            reactor.callLater(ERASE_HASH, self.__eraseHash)
        finally:
            self.mutex.release()

    def __client2Bootstrap(self):
        clientCreator = protocol.ClientCreator(reactor, BootstrapProtocol)
        d = clientCreator.connectTCP(self.egoid.boot, BOOTSTRAP_PORT)
        return d

    def __bsUpdatePktGenerator(self,src):
        linkstr = UPDATE
        for n in self.neighbors.keys():
            delay = self.network[src][n]
        
            linkstr+=PACK_DELIMITER+src+PACK_DELIMITER+n+ \
                        PACK_DELIMITER+str(delay)+ NEIGHBOR_DELIMITER
        #print '-->'*23, linkstr
        return linkstr


    def __peerUpdatePktGenerator(self,src):
        pid     = self.pktid
        self.pktid = (self.pktid+1) % PKT_IDS_LIMIT

        tid     = str(mktime(localtime()))
        hash    = sha1(str(src)+str(tid)+str(pid))
        hash    = hash.hexdigest()
        self.hashdata.add(hash)
        
        linkstr = UPDATE
        linkstr += PACK_DELIMITER+hash+PACK_DELIMITER+str(pid)
        for n in self.neighbors.keys():
            delay = self.network[src][n]
            linkstr+=PACK_DELIMITER+src+PACK_DELIMITER+n+ \
                        PACK_DELIMITER+str(delay)+ NEIGHBOR_DELIMITER
        return linkstr


    def __filterSelf(self, node): return node != self.egoid.netstr
    def __filterNBR(self, node): return node not in self.neighbors
    def __avg(self, iterable): return sum(iterable)/len(iterable)

    def __updateGraph(self, src, dst, delay):
        if src not in self.network.keys():    self.network[src] = dict()
        self.network[src][dst] = delay

    def __swapLinks(self, src, cur, other, delay):
        del self.network[src][cur]
        if src not in self.network.keys(): self.netowkr[src] = dict()
        self.network[src][other]= delay

    def __getPing(self,n):
        d = None
        try:
            d = self.pingdata[n][PING_FACTORY].wire(n)
            
        except Exception,e:
            log.msg('WIRE STILL NONE\t'+str(n))
            pass
        finally:
            return d


    def handleSinglePing(self, data):
        """
        When the deferred is triggered this method is called to
        update the local metric matricies of the peer
        @param data: Peer and link quality
        @type data: python list
        
        """
        self.mutex.acquire(1)
        try:
            KEY, DIFF = xrange(2)
            if data[KEY] in self.pingdata.keys():
                self.pingdata[data[KEY]][PING_RESULTS].pop(0)
                self.pingdata[data[KEY]][PING_RESULTS].append(data[DIFF]*MIL)
                if data[KEY] in self.neighbors.keys():
                     self.network[self.egoid.netstr][data[KEY]] = self.__avg(self.pingdata[data[KEY]][PING_RESULTS])
        except Exception,e:
            print '*'*10, 'Ping Handler Exception', str(e)
        finally:
            self.mutex.release()
   

    def __createNeighbor(self,n):

        nip, nport = n.split(PORT_DELIMITER)
        self.neighbors[n]=dict()
        self.neighbors[n][NBR_IP]       = nip
        self.neighbors[n][NBR_PORT]     = int(nport)
        self.neighbors[n][NBR_FACTORY]  = NeighborTalkingFactory(self.removeNode, n)
        self.neighbors[n][NBR_CONNECTOR]= reactor.connectTCP(nip,self.neighbors[n][NBR_PORT], self.neighbors[n][NBR_FACTORY])


    def __createPingProfile(self,n):
        nip,nport = n.split(PORT_DELIMITER)
        self.pingdata[n] = dict()
        self.pingdata[n][PING_RESULTS] = [BOOT_DELAY,BOOT_DELAY,BOOT_DELAY]
        self.pingdata[n][PING_FACTORY] = PingFactory(n, self.handleSinglePing)
        reactor.connectTCP(nip,int(nport)+1, self.pingdata[n][PING_FACTORY])

    def startFactory(self):
        d = self.__client2Bootstrap()
        d.addCallback(self.__sendBoot, REGISTER, self.egoid.net)
        d.addCallback(self.__initBoot)

    def bootUpdate(self, bsmsg):
        """
        Sending updates to the bootstap node
        @param bsmsg: the actual update message
        @type bsmsg: String
        """
        if bsmsg != '':
            d=self.__client2Bootstrap()
            d.addCallback(self.__sendBoot, UPDATE, bsmsg)
        
    def propagateUpdates(self, peermsg, just_connected):

       """
       propagates updates about graph changes to the direct neighbors
       @param peermsg: the actual message
       @type: String
       @param just_coonected: list with the new neighbors after a local search. For these neighbors we have to wait to initiate a connection to them first
       @type: python list
       """
       for n in self.neighbors.keys():
                if n not in just_connected:
                    if self.neighbors[n][NBR_FACTORY].wire != None:
                        self.__send2Neighbor('',n,peermsg)
                    else:
                        self.neighbors[n][NBR_FACTORY].d.addCallback(self.__send2Neighbor,n,peermsg)

    def isDuplicate(self,hash):
        """
        checks if the incoming packet have been received before
        @param hash: the hash of the incoming update packet
        @type hash: String
        @return: True or False in repsect the result
        @rtype: Boolean
        """
        self.mutex.acquire(1)
        try:
            
            if hash in self.hashdata: return True
            else:
                self.hashdata.add(hash)
            return False
        finally:
            self.mutex.release()

    def isFresh(self,src,id):
        """
        checks if the incoming update is fresh. In other words if the
        counter for the peer that have generated the packet has a different value
        than the one specified in the packet header
        @param src: the peer have generated the update
        @type src: String
        @param id: counter value that was found in the packet header
        @type id: integer
        @return: the result of the check
        @rtype: Boolean
        """
       
        if src in self.netids.keys():
            if id > self.netids[src]:
                self.netids[src] = id
                return True
            return False

        self.netids[src] = dict()
        self.netids[src] = id
        return True
        
        

    def ping(self):
        """
        periodic method that is used to infer the link qualities to
        each one of the rest of the nodes
        """
        self.mutex.acquire(1)
        try:
            currentnet = self.pingdata
            for n in self.pingdata.keys():
                d=self.__getPing(n)                

        except Exception, e:
            print str(e)
            traceback.print_exc()
        finally:
            #print 'Call ping Again', ctime()
            reactor.callLater(PING_PERIOD, self.ping)
            self.mutex.release()
            
            for n in currentnet:
                if self.__avg(currentnet[n][PING_RESULTS]) == HUGE_DELAY:
                    #print '('*20, 'REMOVE from PING', ')'*20
                    self.removeNode(n)
        
            
        
    def removeNode(self, node):
        """
        when is a node is marked as dead. It removes it from the
        internal routing tables as well as sends a remove update to the
        bootstrap node
        @param node: The node will be removed
        @type node: String
        """
        
        bsmsg = REMOVE+PACK_DELIMITER+node
        d = self.__client2Bootstrap()
        d.addCallback(self.__sendBoot,REMOVE, bsmsg )
        self.mutex.acquire(1)
        try:
            if node in self.overlay:    self.overlay.remove(node)
            if node in self.network.keys(): del self.network[node]
            if node in self.pingdata.keys(): del self.pingdata[node]
            if node in self.neighbors.keys(): del self.neighbors[node]
            if node in self.netids.keys():  del self.netids[node]
        finally:
            self.mutex.release()


        
    def processUpdate(self, hash, id, src, rcvPkt ):
        """
        method that processes the incoming updates packets as well
        as decided if will forward them to its neighbors
        @param hash: hash located in the update header
        @type hash: String
        @param id: packet id that defines freshness
        @type id: Integer
        @param src: packet originator
        @type src: String
        @param rcvPkt: the actual recieved data
        @type rcvPkt: String
        """
        
        self.mutex.acquire(1)
        try:
            SRC = 0
            links=[]
            
            # clear the old local state about the originator
            netlinks  = self.network.keys()
            for link in netlinks:
                if src == link:    del self.network[link]

            rcvPktList = rcvPkt.split(NEIGHBOR_DELIMITER)
            for i in rcvPktList:    links.append(i[i.find(PACK_DELIMITER+src):])

            for i in links:
                link = i.split(PACK_DELIMITER)
                if len(link) < 2:  continue
                else:
                    (DUMMY, SRC, DST, DELAY) = xrange(4)
                    self.__updateGraph(link[SRC], link[DST], float(link[DELAY]))
                    self.overlay.add(link[SRC])
                    self.overlay.add(link[DST])


                    if link[SRC] not in self.pingdata.keys() and \
                        link[SRC] != self.egoid.netstr:
                            self.__createPingProfile(link[SRC])

                    if link[DST] not in self.pingdata.keys() and \
                        link[DST] != self.egoid.netstr:
                            self.__createPingProfile(link[DST])
        finally:
            self.mutex.release()
            if self.pingenabled == False:
                self.pingenabled = True
                reactor.callLater(PING_PERIOD*2, self.ping)
                
        
        
        if len(self.neighbors.keys()) < self.egoid.K:   self.formOverlay()
        else:
            if self.brenabled == False and len(self.overlay) > self.egoid.K+1:
                self.brenabled = True
                reactor.callLater(REWIRING_PERIOD, self.localSearch)
            self.propagateUpdates(rcvPkt, [])


    def formOverlay(self):
        """
        method is called to initiate the first neighbors of node
        inside the overlay. Regarding the status of the network this method
        decides if the periodic ping, and localSearch will be enabled
        """
        mynetid = self.egoid.netstr
        if len(self.overlay) == 1: log.msg('No one else inside Egoist Overlay')

        if len(self.overlay) > 1 \
            and len(self.neighbors) < self.egoid.K:
                self.mutex.acquire(1)
                try:
                    
                    nodes = filter(self.__filterSelf, self.overlay)
                    nodes = filter(self.__filterNBR, nodes)
        

                    for n in nodes:
                        if len(self.neighbors) < self.egoid.K and n not in self.neighbors.keys():
                            self.__updateGraph(mynetid,n,BOOT_DELAY)
                            self.__createNeighbor(n)
                        if n not in self.pingdata.keys():
                            self.__createPingProfile(n)
                            

                    if len(nodes) > 0 :
                        bslinkstr   = self.__bsUpdatePktGenerator(mynetid)
                        nbrlinkstr  = self.__peerUpdatePktGenerator(mynetid)
                        self.bootUpdate(bslinkstr)
                
                        for n in self.neighbors.keys():
                            if n in nodes:
                                self.neighbors[n][NBR_FACTORY].d.addCallback(self.__send2Neighbor, n, nbrlinkstr)
                            else:
                                self.propagateUpdates(nbrlinkstr, nodes)

                finally:
                    self.mutex.release()

        if len(self.overlay) >= self.egoid.K +2:
            log.msg('Egoist overlay enabled')
            if self.pingenabled == False:
                reactor.callLater(2*PING_PERIOD,self.ping)
            if self.brenabled == False:
                self.brenabled = True
                reactor.callLater(1.5*REWIRING_PERIOD,self.localSearch)
        

    def selectRandomNeighbors(self, inNeighborsNeed=False, insufficientOverlay=False ):
        """
        method called when a node has lost its neighbors during two
        rewiring periods.
        @attention: not thoroughly tested
        """
        
        neighborsNeed = self.egoid.K - len(self.neighbors)
        over = [i for i in self.overlay if i not in self.neighbors.keys()]
        if inNeighborsNeed:
            for i in range(neighborsNeed):
                while len(self.neighbors) < self.egoid.K:
                    candidate = over[randint(0,len(over))]
                    self.__createNeighbor(candidate)

                    over.remove(candidate)
        elif insufficientOverlay:
            limit  = 0
            if len(over) < neighborsNeed:   limit = len(over)
            else:  limit = neighborsNeed

            for i in range(limit):
                candidate = over[randint(0,len(over))]
                self.__createNeighbor(candidate)
                over.remove(candidate)

        del self.network[self.egoid.netstr]
        self.network[self.egoid.netstr] = dict()
        for i in self.neighbors.keys(): self.network[self.egoid.netstr][i] = BOOT_DELAY
        return


    def localSearch(self):
        """
        The heart of egoist. Local search is called every T=REWIRING_PERIOD
        selected randomly one of the existing links and applies the local
        search heuristic to the rest of the potential links in order to
        select the one that provides the minimum cost for reaching the rest
        of the network. In the beginning are checked some 'corner' cases when
        the egoist peer has lost the one of its neighbors or all of them
        

        """

        if len(self.overlay) < self.egoid.K + 2:
            self.mutex.acquire(1)
            try:
                self.selectRandomNeighbors(True, False)
            finally:
                self.mutex.release()


        elif len(self.neighbors) < self.egoid.K:
            self.mutex.acquire(1)
            try:
                self.selectRandomNeighbors(False, True)
            finally:
                self.mutex.release()

        if len(self.neighbors) == self.egoid.K and \
                    len(self.overlay) >= self.egoid.K + 2:
            self.mutex.acquire(1)
            self.brenabled = True
            try:

                best_score    = 0
                best_neighbor = ''
                best_delay    = 0

                cand = self.neighbors.keys()[randint(0,len(self.neighbors)-1)]
                self.network[self.egoid.netstr][cand] = self.__avg(self.pingdata[cand][PING_RESULTS])
                D,P = Dijkstra(self.network, self.egoid.netstr)
                score, best_score = sum(D.values()), sum(D.values())
                candscore = score
                best_neighbor = cand
                del self.network[self.egoid.netstr][cand]

                for node in self.network.keys():
                    if node in self.neighbors.keys() or node == self.egoid.netstr:
                        continue
                    delay = self.__avg(self.pingdata[node][PING_RESULTS])
                   #print 'POSSIBLE CANDIDATE', node , delay
                    self.__updateGraph(self.egoid.netstr, node, delay)
                    D,P = Dijkstra(self.network,self.egoid.netstr)
                    score = sum(D.values())

                    if score < best_score:
                        best_score    = score
                        best_neighbor = node
                        best_delay    = delay
                    del self.network[self.egoid.netstr][node]

                if best_neighbor not in self.neighbors.keys():
                    
                    self.neighbors[cand][NBR_FACTORY].changingNeighbor = True
                    if self.neighbors[cand][NBR_FACTORY].wire != None:
                        self.neighbors[cand][NBR_FACTORY].wire(TEARDOWN+PACK_DELIMITER)
                    self.neighbors[cand][NBR_FACTORY].disconnectFromNeighbor(self.neighbors[cand][NBR_CONNECTOR])
                    del self.neighbors[cand]
                    
                    self.__updateGraph(self.egoid.netstr, best_neighbor, best_delay)
                    self.__createNeighbor(best_neighbor)
                    D,P = Dijkstra(self.network,self.egoid.netstr)
                    best_score = sum(D.values())
                    print 'SCORE', best_score,  'PING_LEN',  len(self.pingdata.keys()) , 'GRAPH:', len(self.network.keys())
                    
                    
                else:
                    self.__updateGraph(self.egoid.netstr, cand, self.__avg(self.pingdata[cand][PING_RESULTS]))
                    D,P = Dijkstra(self.network,self.egoid.netstr)
                    best_score = sum(D.values())
                    print 'SCORE', best_score,  'PING_LEN',  len(self.pingdata.keys()) , 'GRAPH:', len(self.network.keys())
                    log.msg(str(best_score))


                
                bslinkstr   = self.__bsUpdatePktGenerator(self.egoid.netstr)
                nbrlinkstr  = self.__peerUpdatePktGenerator(self.egoid.netstr)
                self.bootUpdate(bslinkstr)
                for n in self.neighbors.keys():
                    if n == best_neighbor:
                        self.neighbors[n][NBR_FACTORY].d.addCallback(self.__send2Neighbor, n, nbrlinkstr)
                    #else:
                self.propagateUpdates(nbrlinkstr, [best_neighbor])
            finally:
                self.mutex.release()


        reactor.callLater(REWIRING_PERIOD, self.localSearch)
        

def time2str():
    """
    method that returns slightly changed the value of that ctimes returns
    """
    from time import ctime
    s=''
    t=''
    for j in ctime().split(): s+='_'+j
    for i in s:
        if i == ':': t+='_'
        else: t+='_'+i
    return t

 
 
def __getIP(ifname):
    """
    utility method if user doesn't know its ip address
    """
    import fcntl
    import struct 
    from socket import socket
    from socket import AF_INET
    from socket import SOCK_DGRAM
    from socket import inet_ntoa
    
    s =  socket(AF_INET, SOCK_DGRAM)
    return inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

def findNodeIP():
    """
    utility to determine ip address of the node
    @attention: tested for Linux (debian/ubuntu) and MAC
    """
    from os import uname
    NAME   = 0
    IFNUM  = 9
    MAC_OS = 'Darwin'

    name = uname()[NAME]
    ip=''
    if name == MAC_OS:  name='en'
    else:   name='eth'
    for interf in xrange(IFNUM):
        try:
            ip = __getIP(name+str(interf))
            break
        except IOError:
            pass
    return ip


def main():
    from time import sleep
    from sys import stdout
    usage = "usage: python %prog [options]"
    parser = OptionParser(usage, version="%prog 2.0")

    parser.add_option('-i', '--ip_address', action='store', type='string', \
        dest='ip', metavar="IP_ADDRESS", help='host\'s ip address')

    parser.add_option('-p', '--port', action='store', type='int', \
        dest='port', metavar='PORT', help='listening port')

    parser.add_option('-n', '--neighbors', action='store', type='int', \
        dest='k', metavar='NEIGHBORS', help='Number of neighbors')

    parser.add_option('-b', '--bootstrap', action='store', type='string', \
        dest='boot', metavar='BOOTSTRAP_IP', help='Bootstrap Ip')

    parser.add_option('-P', '--peer_boot', action='store', type='string', \
        dest='pBoot', metavar='PEER_BOOTSTRAP', help='Bootstrap Peer')

    parser.add_option('-l', '--log', action='store', type='string', \
        dest='log', metavar='LOG_FILE', help='log filename')


    (options, args) = parser.parse_args()
    if options.ip is None:
        options.ip = findNodeIP()
    if options.port is None:
        parser.error("option -p (--port) is mandatory")
    if options.k is None:
        parser.error('option -n (--neighbors) is mandatory')
    if options.boot is None:
        options.boot = 'localhost'
    if options.log is None:
        options.log = 'SNS'+str(options.k)+'_'+options.ip+time2str()+'.log'
        log.startLogging(open(options.log, 'w'))
    elif options.log != None:
        log.startLogging(open(options.log, 'w'))

    log.msg('Client Started')
    egoID = EgoistNodeID(options.ip, options.port, options.k, options.boot, options.pBoot)
    
    egoFacotry  = EgoistClientFactory(egoID)
    
    reactor.listenTCP(egoID.port,egoFacotry)
    reactor.listenTCP(egoID.port+1, DummyFactory())
    reactor.run()
    

if __name__ == "__main__":
    main()
    
